# Cleaning Up

The following command will delete the `kubernetes` resource group and all related resources created during this tutorial.

```shell
az group delete --name kubernetes --yes --no-wait
```