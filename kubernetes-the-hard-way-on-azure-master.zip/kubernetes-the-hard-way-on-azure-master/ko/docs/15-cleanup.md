# 정리하기

다음 명령은 `kubernetes` 리소스 그룹과 이 자습서를 통해 만들어진 모든 자원들을 삭제합니다.

```shell
az group delete --name kubernetes --yes --no-wait
```
